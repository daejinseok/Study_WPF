//-----------------------------------------------
// EmployeeButton.cs (c) 2006 by Charles Petzold
//-----------------------------------------------
namespace Petzold.ContentTemplateDemo
{
    public partial class EmployeeButton
    {
        public EmployeeButton()
        {
            InitializeComponent();
        }
    }
}
