//---------------------------------------------------------
// XamlCruncherAssemblyInfo.cs (c) 2006 by Charles Petzold
//---------------------------------------------------------
using System.Reflection;

[assembly: AssemblyTitle("XAML Cruncher")]
[assembly: AssemblyProduct("XamlCruncher")]
[assembly: AssemblyDescription("Programming Tool using XamlReader.Load")]
[assembly: AssemblyCompany("www.charlespetzold.com")]
[assembly: AssemblyCopyright("\x00A9 2006 by Charles Petzold")]
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyFileVersion("1.0.0.0")]
