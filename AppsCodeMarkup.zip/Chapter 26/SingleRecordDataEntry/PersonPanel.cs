//--------------------------------------------
// PersonPanel.cs (c) 2006 by Charles Petzold
//--------------------------------------------
namespace Petzold.SingleRecordDataEntry
{
    public partial class PersonPanel
    {
        public PersonPanel()
        {
            InitializeComponent();
        }
    }
}
