//-----------------------------------------------
// CenteredButton.cs (c) 2006 by Charles Petzold
//-----------------------------------------------

namespace Petzold.UseCustomXamlClass
{
    public partial class CenteredButton
    {
        public CenteredButton()
        {
            InitializeComponent();
        }
    }
}
