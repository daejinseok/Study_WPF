//----------------------------------------------
// MyApplication.cs (c) 2006 by Charles Petzold
//----------------------------------------------
using System;
using System.Windows;

namespace Petzold.IncludeApplicationDefinition
{
    public partial class MyApplication : Application
    {
    }
}
