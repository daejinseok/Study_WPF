//---------------------------------------------------------
// NotepadCloneAssemblyInfo.cs (c) 2006 by Charles Petzold
//---------------------------------------------------------
using System.Reflection;

[assembly: AssemblyTitle("Notepad Clone")]
[assembly: AssemblyProduct("NotepadClone")]
[assembly: AssemblyDescription("Functionally Similar to Windows Notepad")]
[assembly: AssemblyCompany("www.charlespetzold.com")]
[assembly: AssemblyCopyright("\x00A9 2006 by Charles Petzold")]
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyFileVersion("1.0.0.0")]
