namespace Petzold.NotepadClone
{
    enum Direction
    {
        Down,
        Up
    }
}
