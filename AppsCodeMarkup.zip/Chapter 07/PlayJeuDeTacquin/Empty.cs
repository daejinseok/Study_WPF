//--------------------------------------
// Empty.cs (c) 2006 by Charles Petzold
//--------------------------------------

namespace Petzold.PlayJeuDeTacquin
{
    class Empty : System.Windows.FrameworkElement
    {
    }
}